package com.movesmart.movesmartapi.service;

import com.fasterxml.jackson.databind.JsonNode;

public interface ReadSetupService {

  JsonNode getDMSSetups();


}

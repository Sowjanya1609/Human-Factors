INSERT INTO PACKERS
VALUES (UUID(), 'NRT', 'jayasri@gmail.com', 'Jaya Sri', 12312313, 'AP');
INSERT INTO PACKERS
VALUES (UUID(), 'SAP', 'jaya@gmail.com', 'Jaya', 98765234, 'AP');
INSERT INTO PACKERS
VALUES (UUID(), 'CPT', 'Sri@gmail.com', 'Sri', 19289382, 'AP');
INSERT INTO PACKERS
VALUES (UUID(), 'NRT', 'js@gmail.com', 'JS', 1231231, 'AP');

package com.movesmart.movesmartapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoveSmartApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
